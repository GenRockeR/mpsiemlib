from mpsiemlib.modules import MPSIEMWorker

__title__ = 'mpsiemlib'
__description__ = 'MaxPatrol SIEM API SDK'
__url__ = 'https://github.com/nikolaiav/mpsiemlib'
__version__ = '1.5.0.2'
__author__ = 'nikolaiav'
__license__ = 'GPLv3'
__copyright__ = '2023, Nikolai Arefiev'
