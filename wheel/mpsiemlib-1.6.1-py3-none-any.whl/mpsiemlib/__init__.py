from mpsiemlib.modules import MPSIEMWorker

__title__ = 'mpsiemlib'
__description__ = 'MaxPatrol SIEM API SDK'
__url__ = 'https://github.com/GenRockeR/mpsiemlib'
__version__ = '1.6.1'
__author__ = 'nikolaiav'
__maintainer__ = 'GenRockeR'
__license__ = 'GPLv3'
__copyright__ = '2025, Nikolai Arefiev, Gennadiy Mukhamedzyanov'
