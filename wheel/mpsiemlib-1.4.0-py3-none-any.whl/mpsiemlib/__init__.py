from mpsiemlib.modules import MPSIEMWorker

__title__ = 'mpsiemlib'
__description__ = 'Maxpatrol SIEM API SDK'
__url__ = 'https://github.com/feedb/MPSiem_addons/tree/master/mpsiemlib'
__version__ = '1.4.0'
__author__ = 'nikolaiav'
__license__ = 'GPLv3'
__copyright__ = ''
